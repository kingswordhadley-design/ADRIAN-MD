import express from 'express';
import pino from 'pino';
import { getLang, textes, messageAccueil, accueilEnvoye, marquerAccueil } from './lib/langue.js';
import { restaurer, planifier, supprimerSauvegarde, toutSauvegarder } from './lib/github.js';
import { webcrypto } from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import * as baileysNs from '@whiskeysockets/baileys';

// Compatible avec les différentes façons dont Baileys exporte ses fonctions
const lib = {
  ...baileysNs,
  ...(typeof baileysNs.default === 'object' ? baileysNs.default : {}),
};
const makeWASocket = typeof baileysNs.default === 'function' ? baileysNs.default : lib.default;
const { useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion, Browsers } = lib;

globalThis.crypto ??= webcrypto;

const PORT = process.env.PORT || 3000;
const SESSIONS_DIR = process.env.SESSIONS_DIR || './sessions';
const ACCESS_KEY = process.env.ACCESS_KEY || ''; // optionnel : protège la page
const PREFIX = '.';
const PAIR_TIMEOUT_MS = 4 * 60 * 1000;

const logger = pino({ level: 'silent' });
const sessions = new Map(); // numéro -> { sock, opened }

// Une erreur imprévue ne doit pas arrêter le bot (sinon coupure + redémarrage)
process.on('unhandledRejection', (e) => console.error('unhandledRejection :', e?.message || e));
process.on('uncaughtException', (e) => console.error('uncaughtException :', e?.message || e));

fs.mkdirSync(SESSIONS_DIR, { recursive: true });

/* ---------- Commandes du bot (dossier commande/) ---------- */
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const COMMANDES_DIR = path.join(__dirname, 'commande');
const commands = new Map();

for (const file of fs.readdirSync(COMMANDES_DIR)) {
  if (!file.endsWith('.js')) continue;
  const mod = await import(pathToFileURL(path.join(COMMANDES_DIR, file)).href);
  const cmd = mod.default;
  commands.set(cmd.name, cmd);
}
console.log(`Commandes chargées : ${[...commands.keys()].join(', ')}`);

async function handleMessage(sock, msg, number) {
  const recu = performance.now(); // instant où le bot reçoit le message
  if (!msg.message || msg.key.remoteJid === 'status@broadcast') return;
  if (!msg.key.fromMe) return; // bot perso : seul le propriétaire du numéro peut l'utiliser

  const text =
    msg.message.conversation ||
    msg.message.extendedTextMessage?.text ||
    '';
  if (!text.startsWith(PREFIX)) return;

  const [rawName, ...args] = text.slice(PREFIX.length).trim().split(/\s+/);
  const name = rawName.toLowerCase();
  const cmd = commands.get(name);
  if (!cmd) return;

  // Tant que la langue n'est pas choisie, seules .fr .en .es sont autorisées
  if (!getLang(number) && !['fr', 'en', 'es'].includes(name)) {
    await sock.sendMessage(msg.key.remoteJid, { text: messageAccueil(PREFIX) }, { quoted: msg });
    return;
  }

  const t = textes(getLang(number));
  const reply = await cmd.run({ sock, msg, commands, prefix: PREFIX, number, args, t, recu });
  if (!reply) return;
  // Une commande peut renvoyer du texte, ou un message complet (image, carte, etc.)
  const content = typeof reply === 'string' ? { text: reply } : reply;
  await sock.sendMessage(msg.key.remoteJid, content, { quoted: msg });
}

/* ---------- Gestion des sessions ---------- */
function destroySession(number) {
  const s = sessions.get(number);
  if (s) {
    try { s.sock.end(undefined); } catch {}
    sessions.delete(number);
  }
  fs.rmSync(path.join(SESSIONS_DIR, number), { recursive: true, force: true });
  supprimerSauvegarde(number); // efface aussi la sauvegarde GitHub de ce numéro
}

// onCode(err, code) n'est passé que pour un nouveau jumelage
async function startSession(number, { onCode = null, trusted = false } = {}) {
  const dir = path.join(SESSIONS_DIR, number);
  const { state, saveCreds } = await useMultiFileAuthState(dir);
  // Version actuelle de WhatsApp Web (une version périmée fait échouer le jumelage)
  let version;
  try {
    if (lib.fetchLatestWaWebVersion) {
      ({ version } = await lib.fetchLatestWaWebVersion());
    }
    if (!version) ({ version } = await fetchLatestBaileysVersion());
  } catch (e) {
    console.error('Version WhatsApp non récupérée, valeur par défaut utilisée :', e.message);
  }
  console.log(`[${number}] version WhatsApp Web : ${version ? version.join('.') : 'défaut'}`);

  const sock = makeWASocket({
    version,
    auth: state,
    logger,
    browser: Browsers.ubuntu('Chrome'),
    printQRInTerminal: false,
    markOnlineOnConnect: false,
  });

  const entry = { sock, opened: trusted, connecte: false };
  sessions.set(number, entry);

  sock.ev.on('creds.update', async () => {
    await saveCreds();
    planifier(number, dir); // sauvegarde GitHub dans quelques secondes
  });

  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;
    for (const msg of messages) {
      try { await handleMessage(sock, msg, number); } catch (e) { console.error(number, e.message); }
    }
  });

  let pairTimer = null;
  const wantsCode = Boolean(onCode) && !state.creds.registered;
  let codeRequested = false;

  async function requestCode() {
    try {
      const pairing = await sock.requestPairingCode(number);
      console.log(`[${number}] code de jumelage généré`);
      onCode(null, pairing);
      pairTimer = setTimeout(() => {
        if (!entry.opened) destroySession(number);
      }, PAIR_TIMEOUT_MS);
    } catch (e) {
      console.error(`[${number}] échec requestPairingCode :`, e.message);
      destroySession(number);
      onCode(e);
    }
  }

  sock.ev.on('connection.update', ({ connection, lastDisconnect, qr }) => {
    // Le code est demandé quand la connexion à WhatsApp est prête (événement qr)
    if (qr && wantsCode && !codeRequested) {
      codeRequested = true;
      requestCode();
    }
    if (connection) {
      console.log(
        `[${number}] connexion : ${connection}`,
        lastDisconnect?.error?.output?.statusCode ?? ''
      );
    }

    if (connection === 'open') {
      entry.opened = true;
      entry.connecte = true;
      if (pairTimer) clearTimeout(pairTimer);
      console.log(`[${number}] connecté`);
      planifier(number, dir, 5000); // sauvegarde GitHub juste après la connexion

      // Message de bienvenue en 3 langues, envoyé une seule fois (dans « Moi-même »)
      if (!getLang(number) && !accueilEnvoye(number)) {
        const moi = sock.user.id.split(':')[0].split('@')[0] + '@s.whatsapp.net';
        sock
          .sendMessage(moi, { text: messageAccueil(PREFIX) })
          .then(() => marquerAccueil(number))
          .catch((e) => console.error(`[${number}] bienvenue non envoyée :`, e.message));
      }
    }

    if (connection === 'close') {
      const code = lastDisconnect?.error?.output?.statusCode;
      entry.connecte = false;
      if (sessions.get(number) !== entry) return; // session déjà remplacée ou supprimée

      if (code === DisconnectReason.loggedOut) {
        console.log(`[${number}] déconnecté depuis WhatsApp, session supprimée`);
        destroySession(number);
      } else if (code === DisconnectReason.connectionReplaced) {
        // La même session s'est ouverte ailleurs (ex. ancienne instance Render encore active) :
        // on ne se reconnecte pas, sinon les deux s'éjectent en boucle.
        console.log(`[${number}] session ouverte ailleurs (440), reconnexion annulée`);
        sessions.delete(number);
      } else if (code === DisconnectReason.restartRequired || entry.opened || state.creds.registered) {
        // redémarrage normal après jumelage, ou coupure : on se reconnecte sans toucher à la session
        setTimeout(() => startSession(number, { trusted: true }).catch(console.error), 3000);
      } else {
        destroySession(number); // jumelage jamais terminé
      }
    }
  });
}

/* ---------- Serveur web ---------- */
const app = express();
app.use(express.json());
app.use(express.static('public'));

app.get('/health', (_req, res) => res.send('ok'));

app.get('/api/config', (_req, res) => res.json({ keyRequired: Boolean(ACCESS_KEY) }));

app.post('/api/pair', async (req, res) => {
  const { number: raw = '', key = '' } = req.body || {};
  if (ACCESS_KEY && key !== ACCESS_KEY) {
    return res.status(401).json({ error: "Clé d'accès incorrecte." });
  }

  const number = String(raw).replace(/\D/g, '');
  if (number.length < 8 || number.length > 15) {
    return res.status(400).json({
      error: 'Numéro invalide. Saisis-le avec l’indicatif, sans + ni espaces (ex. 33612345678).',
    });
  }

  if (number.startsWith('0')) {
    return res.status(400).json({
      error: 'Ajoute l’indicatif du pays au début, sans le 0 (ex. 33612345678 au lieu de 0612345678).',
    });
  }

  const existing = sessions.get(number);
  if (existing?.connecte) {
    return res.status(409).json({ error: 'Ce numéro est déjà connecté au bot.' });
  }
  // Nouveau code demandé : on efface la session locale ET la sauvegarde GitHub de ce numéro
  destroySession(number);

  let answered = false;
  const answer = (status, body) => {
    if (answered) return;
    answered = true;
    res.status(status).json(body);
  };

  try {
    await startSession(number, {
      onCode: (err, code) => {
        if (err) return answer(500, { error: 'Impossible d’obtenir le code. Réessaie dans un instant.' });
        answer(200, { code });
      },
    });
  } catch (e) {
    console.error('Erreur startSession :', e);
    answer(500, { error: `Erreur au démarrage de la session : ${e.message}` });
  }
});

app.listen(PORT, async () => {
  console.log(`Serveur prêt sur le port ${PORT}`);
  // Récupère les sessions sauvegardées sur GitHub si le disque local est vide
  await restaurer(SESSIONS_DIR).catch((e) => console.error('[github] restauration :', e.message));
  // Rétablit les sessions déjà jumelées après un redémarrage
  const trouvees = fs.readdirSync(SESSIONS_DIR).filter((n) => /^\d{8,15}$/.test(n));
  console.log(`Dossier des sessions : ${path.resolve(SESSIONS_DIR)} (${trouvees.length} session(s) trouvée(s))`);
  for (const number of trouvees) {
    startSession(number, { trusted: true }).catch(console.error);
  }
});

// Sauvegarde GitHub régulière + avant l'arrêt du serveur (redémarrage / redéploiement Render)
setInterval(() => toutSauvegarder(SESSIONS_DIR), 5 * 60 * 1000);
process.on('SIGTERM', async () => {
  console.log('Arrêt du serveur : sauvegarde des sessions...');
  await toutSauvegarder(SESSIONS_DIR);
  process.exit(0);
});
